# JPetStore
Sample application for PBL in the SSD class in 2018-1

주의: 
  먼저 이 리파지토리(https://github.com/cspark0/JPetStore )를 우측 상단의 Fork 버튼을 클릭하여 자신 또는 팀 계정으로 Fork 한 후 사용하기 바랍니다. 


STS 또는 Eclipse에 import하는 방법:
  File >> Import... >> Git > Projects from Git >> Clone URI >> fork된 URI 입력(ex.https://github.com/계정명/JPetStore.git)


Git 사용법:
  https://backlog.com/git-tutorial/kr/,
  https://nolboo.kim/blog/2013/10/06/github-for-beginner/ 및 링크된 문서들, 
  http://itmir.tistory.com/461, 
  http://jwgye.tistory.com/38?category=689862, 그밖의 온라인 자료들
